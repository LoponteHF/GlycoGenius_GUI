from glycogenius_GUI.GUI import run_main_window as main

def glycogenius_GUI():
    main()