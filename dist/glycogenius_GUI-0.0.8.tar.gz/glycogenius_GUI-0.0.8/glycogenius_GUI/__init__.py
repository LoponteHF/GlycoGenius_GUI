from glycogenius_GUI.GUI import main

def glycogenius_GUI():
    main()