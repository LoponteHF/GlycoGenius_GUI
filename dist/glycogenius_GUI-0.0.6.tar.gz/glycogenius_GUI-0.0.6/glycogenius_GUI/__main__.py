from glycogenius_GUI.GUI import run_main_window as main

if __name__ == "__main__":
	main()